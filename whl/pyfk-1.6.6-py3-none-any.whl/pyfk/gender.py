from enum import Enum

class Gender(Enum):
    """
    Gender

    author: weston
    """

    # 男
    MAN = "MAN"

    # 女
    WOMAN = "WOMAN"