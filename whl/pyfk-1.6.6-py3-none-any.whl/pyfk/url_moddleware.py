import threading
import json
from json import JSONDecodeError
from starlette.requests import Request
from starlette.responses import Response
from starlette.middleware.base import BaseHTTPMiddleware
from .overrider import override

class UrlMiddleware(BaseHTTPMiddleware):
    """
    針對指定url所使用的middleware, 監聽該url的觸發事件

    使用方法:
        繼承此類後實作action(), 需搭配@url_middleware使用

    author: weston
    """

    # 監聽url path
    _path: str

    # 監聽url path的method, e.g.: get, post, put, delete
    _method: str

    # 使用同步
    _async: bool

    def _make_receive(self, body: bytes):
        """
        每次呼叫都回傳一個新的 receive callable，
        內部 closure 保留 body bytes，讓不同的 Request 可以重放 body。
        """
        async def receive():
            return {"type": "http.request", "body": body, "more_body": False}
        return receive

    @override(BaseHTTPMiddleware)
    async def dispatch(self, request: Request, call_next):
        # 檢查是否使用@url_middleware指定url及method
        if not (self._path and self._method):
            raise Exception(f"class {self.__class__.__name__} doesn't use @url_middleware assign url and method")

        # 檢查method及url path是否吻合
        if self.__check_method(request.method) and self.__check_url(request.url.path):
            # 先讀 raw body bytes（安全），再嘗試解析 JSON（若是 application/json）
            body_bytes = await request.body()  # 可能是 b''

            parsed_json = None
            content_type = request.headers.get("content-type", "")
            if body_bytes and "application/json" in content_type.lower():
                try:
                    parsed_json = json.loads(body_bytes)
                except JSONDecodeError:
                    parsed_json = None

            # 為了讓下游可以再次讀到 body，建立一個新的 Request，使用 replay receive
            receive_for_next = self._make_receive(body_bytes)
            request_for_next = Request(request.scope, receive_for_next)

            # call_next with the new request that will replay the body
            response = await call_next(request_for_next)

            # 決定要怎麼呼叫 action：同步或非同步（threaded）
            if self._async:
                # 在 thread 中執行 action
                # 建立另一個 Request 來傳給 action（同樣用 replay receive）
                # 注意：把 Request 物件傳到新 thread 可能有風險（視 action 實作而定）。
                # 更安全的做法是只傳入序列化必要欄位（見下方建議）。
                receive_for_action = self._make_receive(body_bytes)
                request_for_action = Request(request.scope, receive_for_action)

                t = threading.Thread(
                    target=self.action,
                    args=[
                        request_for_action,
                        response,
                        request_for_action.path_params,
                        dict(request_for_action.query_params),
                        parsed_json
                    ],
                    daemon=True
                )
                t.start()
            else:
                # 同步呼叫 action（在同一個事件迴圈）
                # 這裡也建立一個 fresh Request 以確保 body 可再次被讀取
                receive_for_action = self._make_receive(body_bytes)
                request_for_action = Request(request.scope, receive_for_action)

                self.action(
                    request_for_action,
                    response,
                    request_for_action.path_params,
                    dict(request_for_action.query_params),
                    parsed_json
                )

        else:
            # 若不符合監聽條件，直接把原始 request（不改）傳給下游
            response = await call_next(request)

        return response

    def __check_method(self, request_method: str) -> bool:
        """
        檢查request_method與self._method是否吻合
        """
        if request_method.strip() == "*":
            return True

        if self._method == request_method:
            return True

        return False

    def __check_url(self, request_url: str) -> bool:
        """
        檢查request_url與self._path是否吻合
        """
        if request_url.strip() == "*":
            return True

        request_url_tmp = request_url.split("/")
        listen_url_tmp = self._path.split("/")

        if len(request_url_tmp) < len(listen_url_tmp):
            return False

        for i in range(len(listen_url_tmp)):
            v = listen_url_tmp[i]
            if v == "*":
                return True
            elif not v == request_url_tmp[i]:
                return False

        return True

    def action(
        self,
        request: Request,
        response: Response,
        path_param: dict,
        query_param: dict,
        request_body: dict
    ) -> Response:
        return NotImplemented

def url_middleware(url: str, method: str, is_async: bool = False):
    """
    指定監聽的url及method

    args:
        url: url
        method: url method, e.g.: get, post, put, delete
        is_async: use async, default False

    author: weston
    """
    assert(url != "")
    assert(method != "")

    def wrap(cls):
        # 檢查是否繼承UrlMiddleware
        assert(issubclass(cls, UrlMiddleware))
        cls._path = url
        cls._method = method.upper()
        cls._async = is_async
        return cls

    return wrap
