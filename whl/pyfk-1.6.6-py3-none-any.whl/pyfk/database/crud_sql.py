from fastapi import HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session
from starlette.status import HTTP_400_BAD_REQUEST
from .session import get_db_session
from typing import Any, Generic, TypeVar, List, final
from datetime import datetime
from .abstract_table import AbstractTable

T = TypeVar("T", bound=AbstractTable)

M = TypeVar("M", bound=BaseModel)

class CrudSql(Generic[T]):

    table: T

    def __init__(self, db: Session = None):
        """
        args:
            table: table class
            db(option): db session
        """
        self.db = db if db else next(get_db_session())

    def __init_subclass__(cls, **kwargs: Any):
        super().__init_subclass__(**kwargs)
        for base in cls.__orig_bases__:
            if hasattr(base, "__args__"):
                cls.table = base.__args__[0]
                break

    @final
    def get_one(self, **filter) -> T:
        """
        get one data from database

        args:
            **filter: column filter

        return:
            data found
        """
        r = self.get_list(limit=1, **filter)
        return None if not r else r[0]

    @final
    def get_by_uid(self, uid: int) -> T:
        """
        get one data by uid

        args:
            uid: uid value

        return:
            data found
        """
        return self.get_one(uid=uid)

    @final
    def get_list(self, limit: int = None, *order_by, **filter) -> List[T]:
        """
        get list data from database

        args:
            limit: limit of data rows
            *order_by: order by
            **filter: column filter

        return:
            data list found
        """
        r = self.db.query(self.table)
        if filter:
            r = r.filter_by(**filter)
        if order_by:
            r = r.order_by(*order_by)
        if limit:
            r = r.limit(limit)
        r = r.all()
        return r

    @final
    def create(self, source: T) -> T:
        """
        create and commit one row data

        args:
            source: data source

        return:
            data after created
        """
        self.db.add(source)
        self.db.commit()
        self.db.refresh(source)
        return source

    @final
    def create_batch(self, sources: List[T], refresh: bool = True) -> List[T]:
        """
        create and commit rows data batch

        args:
            sources: batch create data sources
            refresh: refresh sources data

        return:
            data list after created
        """
        batch_size = 500

        for i in range(0, len(sources), batch_size):
            batch = sources[i:i + batch_size]
            self.db.add_all(batch)
            self.db.commit()

        if refresh:
            for s in sources:
                self.db.refresh(s)
        return sources

    @final
    def merge_to_target(self, target_uid: str, source: M) -> T:

        target = self.get_by_uid(target_uid)

        if not target:
            raise HTTPException(status_code=HTTP_400_BAD_REQUEST,
                detail="merge failed cause can't find %s data by uid: %s" % 
                    (self.table.__tablename__, target_uid)
            )
        
        for c in source.model_fields:
            if c not in ("uid", "create_time", "lm_time") and hasattr(target, c):
                setattr(target, c, getattr(source, c))
        
        return target

    @final
    def update(self, source: T, lm_user: str = None) -> T:
        """
        update and commit one row data

        args:
            source: data source

        return:
            data after updated
        """
        source.lm_time = datetime.now()
        if lm_user:
            source.lm_user = lm_user
        self.db.commit()
        self.db.refresh(source)
        return source

    @final
    def delete(self, source: T):
        """
        delete and commit one row data

        args:
            source: data source
        """
        self.db.delete(source)
        self.db.commit()

    @final
    def delete_by_uid(self, uid: int):
        """
        delete and commit data by uid

        args:
            uid: uid value
        """
        self.db.delete(self.get_by_uid(uid))
        self.db.commit()

    @final
    def commit(self):
        """
        commit db session
        """
        self.db.commit()

    @final
    def roll_back(self):
        """
        rollback db session
        """
        self.db.rollback()

    @final
    def refresh(self, source: T) -> T:
        """
        refresh db session
        """
        self.db.refresh(source)
